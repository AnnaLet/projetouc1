const express = require('express');
const consulta = require('./database');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

app.get('/conectafornecedores', function (req, res) {
    consulta.query('SELECT * FROM fornecedores;', function (error, resultado) {
        if (error) {
            res.send("Houve um erro na solicitação"+error);
        } else {
            res.send(resultado.rows);
        }
    });
});
app.post('/conectafornecedores', function (req, res){
    const { descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim, ativo } = req.body;
    consulta.query(
        `INSERT INTO fornecedores (descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim, ativo) VALUES ('${descricao}', '${categoria}', '${contato}', '${nome_anunciante}','${cpf_cnpj}','${hora_inicio}','${hora_fim}','${ativo}')`,
function (error, resultado){

  if (error) {
    res.status(401).json("erro ao inserir informações no banco de dados");            
    
            } else {
                
                res.send("Fornecedor cadastrado!");
            }
        });
    });

    app.listen(3000, function () {
        console.log('Servidor rodando na porta 3000');
    });

CREATE TABLE fornecedores (
    id SERIAL PRIMARY KEY,
    descricao TEXT NOT NULL,
    categoria VARCHAR(50),
    contato VARCHAR(100) NOT NULL,
    nome_anunciante VARCHAR(80) NOT NULL,
    cpf_cnpj VARCHAR(14) NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    data_criacao TIMESTAMPTZ DEFAULT NOW(),
    ativo BOOLEAN DEFAULT TRUE
);


INSERT INTO fornecedores
(descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim, ativo)
VALUES
('Aulas particulares de lógica de programação', 'Educação', 'prof.lucas@example.com', 'Lucas Andrade', '12345678901', '08:00', '12:00', TRUE),
('Manutenção de notebooks e PCs', 'Tecnologia', '55 11999990001', 'Carla Mendes', '98765432100', '09:00', '18:00', TRUE),
('Design de logos e identidade visual', 'Design', 'studio@criativo.com', 'Estúdio Criativo', '11222333000181', '10:00', '16:00', TRUE),
('Consultoria de marketing digital', 'Marketing', 'mkt@agenciagrowth.com', 'Agência Growth', '22333444000162', '09:30', '17:30', TRUE),
('Serviço de jardinagem residencial', 'Casa e Jardim', '11 98888-0002', 'Pedro Silva', '45678912345', '07:00', '11:00', TRUE),
('Conserto de eletrodomésticos', 'Serviços Gerais', 'consertafacil@example.com', 'Conserta Fácil', '33444555000143', '08:30', '17:00', TRUE),
('Aulas de inglês online', 'Educação', 'teacher.ana@example.com', 'Ana Paula', '32165498700', '18:00', '21:00', TRUE),
('Desenvolvimento de sites simples', 'Tecnologia', 'web@devsimples.com', 'Dev Simples', '44555666000124', '13:00', '18:00', TRUE),
('Fotografia de eventos', 'Eventos', 'fotos@momentos.com', 'Momentos Fotografias', '55666777000105', '14:00', '22:00', TRUE),
('Buffet para festas pequenas', 'Gastronomia', 'contato@festabuffet.com', 'Festa Buffet', '66777888000196', '10:00', '20:00', TRUE),
('Aulas de violão iniciante', 'Educação', 'prof.renato@example.com', 'Renato Dias', '74185296300', '15:00', '19:00', TRUE),
('Passeio e cuidado de pets', 'Pets', 'cuidadodepets@example.com', 'Bruna Costa', '85236974100', '08:00', '12:00', TRUE),
('Edição de vídeo básica', 'Audiovisual', 'edita@videoexpress.com', 'Video Express', '77888999000177', '09:00', '15:00', TRUE),
('Reformas e pequenos reparos', 'Construção', 'tiago.reformas@example.com', 'Tiago Moreira', '96325874100', '08:00', '17:00', TRUE),
('Consultoria financeira pessoal', 'Consultoria', 'financas@planob.com', 'Plano B Consultoria', '88999000000158', '10:00', '18:00', TRUE),
('Criação de artes para redes sociais', 'Design', 'social@midiaarte.com', 'MidiaArte', '90001111000139', '11:00', '19:00', TRUE),
('Aulas de matemática para ENEM', 'Educação', 'prof.marina@example.com', 'Marina Alves', '15975348620', '18:30', '21:30', TRUE),
('Programação de automações com Python', 'Tecnologia', 'py@automatiza.ai', 'Automatiza.AI', '91112222000110', '13:30', '17:30', TRUE),
('Consultoria em UX básica', 'Design', 'ux@experiencia.co', 'Experiência Co', '92223333000101', '09:00', '13:00', TRUE),
('Tradução PT-EN', 'Línguas', 'traducao@fasttranslate.com', 'Fast Translate', '93334444000182', '10:00', '16:00', TRUE),
('Aulas de HTML/CSS para iniciantes', 'Educação', 'curso.front@example.com', 'Curso Front', '24681357901', '19:00', '21:00', TRUE),
('Serviço de babá eventual', 'Serviços Gerais', 'baba@confiavel.com', 'Baba Confiável', '94445555000163', '08:00', '14:00', TRUE),
('Criação de chatbots simples', 'Tecnologia', 'bot@dialogos.tech', 'Diálogos Tech', '95556666000144', '10:00', '18:00', TRUE),
('Consultoria LGPD básica', 'Consultoria', 'lgpd@privacycare.com', 'Privacy Care', '96667777000125', '09:00', '12:00', TRUE),
('Assessoria de imprensa', 'Comunicação', 'press@midiarelacoes.com', 'Mídia Relações', '97778888000106', '10:00', '17:00', TRUE),
('Personal trainer iniciante', 'Saúde', 'treino@fitstart.com', 'Fit Start', '36925814702', '06:00', '10:00', TRUE),
('Manutenção de redes domésticas', 'Tecnologia', 'rede@netfix.com', 'NetFix', '98889999000187', '09:00', '18:00', TRUE),
('Ilustração para livros infantis', 'Design', 'ilustra@colorarte.com', 'ColorArte', '99900011000168', '11:00', '17:00', TRUE),
('Diagramação de e-books', 'Editorial', 'ebook@diagramax.com', 'Diagramax', '00011122000149', '13:00', '19:00', TRUE),
('Consultoria para TCC', 'Educação', 'tcc@orientaedu.com', 'Orienta EDU', '11122233000120', '14:00', '20:00', TRUE);
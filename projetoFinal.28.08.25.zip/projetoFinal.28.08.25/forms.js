function MensagemCadastro() {
    const formulario = document.getElementById('form-fornecedor');

    formulario.addEventListener('submit', function(evento) {
        evento.preventDefault(); // Para evitar que o formulário recarregue a página

        const dados = {
            nome_anunciante: document.getElementById('nome_anunciante').value,
            descricao: document.getElementById('descricao').value,
            categoria: document.getElementById('categoria').value,
            contato: document.getElementById('contato').value,
            cpf_cnpj: document.getElementById('cpf_cnpj').value,
            hora_inicio: document.getElementById('hora_inicio').value,
            hora_fim: document.getElementById('hora_fim').value
        };

        fetch('http://localhost:3000/conectafornecedores', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dados)
        })
        .then(function(resposta) {
            return resposta.json();
        })
        .then(function(resposta) {
            const mensagem = document.getElementById('mensagem');
            mensagem.innerText = 'Fornecedor cadastrado: ' + resposta.nome_anunciante;
        })
        .catch(function(erro) {
            const mensagem = document.getElementById('mensagem');
            mensagem.innerText = 'ERROR! FALHA AO CONECTAR O SERVIDOR!';
            console.log(erro);
        });
    });
}

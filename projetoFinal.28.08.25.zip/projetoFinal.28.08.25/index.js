
    // Declara uma variável global para guardar todos os prestadores
    var todosFornecedores = [];

    // FUNÇÃO 1: Carregar prestadores da API
    function carregarFornecedores() {
      // Pega o elemento HTML onde vamos mostrar os prestadores
      var container = document.getElementById('fornecedores-container');
      
      // Mostra mensagem de "carregando" enquanto busca os dados
      container.innerHTML = '<div class="loading">Carregando profissionais...</div>';

      // Faz a requisição HTTP para buscar os dados da API
      fetch('http://localhost:3000/conectafornecedores')
        // Quando a resposta chegar, converte para JSON
        .then(function (response) {
          return response.json();
        })
        // Quando os dados JSON estiverem prontos, processa eles
        .then(function (data) {
          // Assume que a API retorna diretamente um array de prestadores
          var fornecedores = data;

          // Guarda todos os prestadores na variável global (para usar na busca)
          todosFornecedores = fornecedores;

          // Pega apenas os primeiros 20 prestadores para não sobrecarregar a tela
          var primeiros20 = fornecedores.slice(0, 20);
          
          // Chama a função que vai mostrar os prestadores na tela
          mostrarFornecedores(primeiros20);

          // Ativa a funcionalidade de busca por nome
          configurarBusca();
        })
        // Se der algum erro na requisição, mostra mensagem de erro
        .catch(function (error) {
          console.log('Erro ao carregar fornecedores:', error);
          container.innerHTML = '<div class="error">Erro ao carregar profissionais. Verifique se a API está rodando.</div>';
        });
    }

    // FUNÇÃO 2: Mostrar prestadores na tela
    function mostrarFornecedores(fornecedores) {
      // Pega o elemento onde vamos colocar os cartões dos prestadores
      var container = document.getElementById('fornecedores-container');
      
      // Limpa todo o conteúdo anterior do container
      container.innerHTML = '';

      // Verifica se a lista de prestadores está vazia ou não é um array
      if (!Array.isArray(fornecedores) || fornecedores.length === 0) {
        // Se não tem prestadores, mostra mensagem informativa
        container.innerHTML = '<div class="empty">Nenhum profissional encontrado</div>';
        return; // Para a execução da função aqui
      }

      // Percorre cada prestador da lista usando for...of
      for (const fornecedor of fornecedores) {
        // Cria um novo elemento div para ser o cartão do prestador
        var cartao = document.createElement('div');
        // Define a classe CSS do cartão
        cartao.className = 'cartao-prestador';

        // Extrai os dados do prestador, usando valores padrão se algum campo estiver vazio
        var categoria = fornecedor.categoria || 'Geral';
        var nome = fornecedor.nome_anunciante || 'Nome não informado';
        var descricao = fornecedor.descricao || 'Descrição não disponível';
        var contato = fornecedor.contato || 'Não informado';
        var horaInicio = fornecedor.hora_inicio || '--';
        var horaFim = fornecedor.hora_fim || '--';

        // Monta o HTML interno do cartão usando template literals (crase ``)
        cartao.innerHTML = `
          <div class="cabecalho-cartao">
            <div class="etiqueta-prestador">${categoria}</div>
          </div>
          <h3 class="titulo-prestador">${nome}</h3>
          <p class="descricao-prestador">${descricao}</p>
          <div class="detalhes-prestador">
            <div class="info-contato"><strong>Contato:</strong> ${contato}</div>
            <div class="info-horario"><strong>Horário:</strong> ${horaInicio} às ${horaFim}</div>
          </div>
        `;

        // Cria o botão "Entrar em Contato"
        var botao = document.createElement('button');
        // Define a classe CSS do botão
        botao.className = 'botao-contato-primario';
        // Define o texto que aparece no botão
        botao.textContent = 'Entrar em Contato';

        // Usa uma closure (função dentro de função) para "capturar" o contato correto
        // Isso é necessário porque o loop muda a variável 'contato', mas queremos
        // que cada botão "lembre" do contato do SEU prestador específico
        (function (contatoAtual) {
          // Define o que acontece quando clica no botão
          botao.onclick = function () {
            // Chama a função que mostra o contato
            mostrarContato(contatoAtual);
          };
        })(contato); // Passa o contato atual para a closure

        // Adiciona o botão dentro do cartão
        cartao.appendChild(botao);
        
        // Adiciona o cartão completo dentro do container principal
        container.appendChild(cartao);
      }
    }

    // FUNÇÃO 3: Mostrar informações de contato
    function mostrarContato(contato) {
      // Verifica se o contato existe e não é "Não informado"
      if (contato && contato !== 'Não informado') {
        // Mostra um alert com as informações de contato
        alert('Entre em contato: ' + contato);
      } else {
        // Se não tem contato, mostra mensagem informativa
        alert('Informações de contato não disponíveis');
      }
    }

    // FUNÇÃO 4: Configurar busca por nome
    function configurarBusca() {
      // Pega o campo de input onde o usuário digita a busca
      var campoBusca = document.getElementById('busca-nome');

      // Adiciona um "ouvinte" que escuta quando o usuário digita algo
      campoBusca.addEventListener('input', function () {
        // Pega o texto que o usuário digitou e converte para minúsculo
        var textoBusca = this.value.toLowerCase();

        // Filtra a lista global de prestadores
        var filtrados = todosFornecedores.filter(function (f) {
          // Pega o nome do prestador e converte para minúsculo
          var nome = (f.nome_anunciante || '').toLowerCase();
          // Verifica se o nome contém o texto da busca
          return nome.indexOf(textoBusca) !== -1;
        });

        // Mostra apenas os prestadores que passaram no filtro
        mostrarFornecedores(filtrados);
      });
    }

    // FUNÇÃO 5: Configurar scroll suave para links internos
    function configurarScrollSuave() {
      // Pega todos os links que começam com # (links internos da página)
      var links = document.querySelectorAll('a[href^="#"]');

      // Percorre cada link encontrado
      for (var i = 0; i < links.length; i++) {
        // Adiciona um ouvinte de clique para cada link
        links[i].addEventListener('click', function (e) {
          // Impede o comportamento padrão do link (pular direto para a seção)
          e.preventDefault();
          
          // Pega o ID da seção de destino (ex: "#inicio")
          var destinoId = this.getAttribute('href');
          
          // Procura o elemento com esse ID na página
          var destinoEl = document.querySelector(destinoId);
          
          // Se encontrou o elemento, faz o scroll suave até ele
          if (destinoEl) {
            destinoEl.scrollIntoView({ behavior: 'smooth' });
          }
        });
      }
    }

    // EVENTO: Quando a página terminar de carregar completamente
    document.addEventListener('DOMContentLoaded', function () {
      // Carrega os prestadores da API
      carregarFornecedores();
      
      // Configura o scroll suave para os links internos
      configurarScrollSuave();
    });
 